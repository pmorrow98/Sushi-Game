package sushigame.view;

public interface RotationRequestListener {

	void handleRotationRequest();
}
