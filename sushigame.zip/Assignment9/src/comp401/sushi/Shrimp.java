package comp401.sushi;

public class Shrimp extends IngredientImpl {

	public Shrimp() {
		super("shrimp", 0.55, 39, false, false, true);
	}
}
