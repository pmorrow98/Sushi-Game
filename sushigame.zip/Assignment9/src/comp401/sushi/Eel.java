package comp401.sushi;

public class Eel extends IngredientImpl {

	public Eel() {
		super("eel", 2.18, 84, false, false, false);
	}
}
