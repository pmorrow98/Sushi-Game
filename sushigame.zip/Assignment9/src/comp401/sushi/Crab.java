package comp401.sushi;

public class Crab extends IngredientImpl {

	public Crab() {
		super("crab", 0.75, 36, false, false, true);
	}
}
