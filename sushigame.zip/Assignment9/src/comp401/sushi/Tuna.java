package comp401.sushi;

public class Tuna extends IngredientImpl {

	public Tuna() {
		super("tuna", 1.77, 48, false, false, false);
	}
}
